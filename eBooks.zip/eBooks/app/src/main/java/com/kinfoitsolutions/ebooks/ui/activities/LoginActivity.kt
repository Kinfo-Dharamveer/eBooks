package com.kinfoitsolutions.ebooks.ui.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.kinfoitsolutions.ebooks.R
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        btnLoginGoogle.setOnClickListener {
            startActivity(Intent(this@LoginActivity, MainActivity::class.java))
        }

    }
}
