package com.kinfoitsolutions.ebooks.ui.activities

import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import androidx.navigation.NavController
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.toolbar_main.*
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem
import com.kinfoitsolutions.ebooks.R


class MainActivity : AppCompatActivity() {

    lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.kinfoitsolutions.ebooks.R.layout.activity_main)

        setSupportActionBar(main_toolbar)

       // bottom_navigation

        val home = AHBottomNavigationItem("Home", R.drawable.ic_home, R.color.black)
        val category = AHBottomNavigationItem("Category", R.drawable.ic_menu,R.color.black)
        val library = AHBottomNavigationItem("My Library", R.drawable.ic_library, R.color.black)
        val settings = AHBottomNavigationItem("Settings", R.drawable.ic_settings, R.color.black)

        // Add items
        bottom_navigation.addItem(home)
        bottom_navigation.addItem(category)
        bottom_navigation.addItem(library)
        bottom_navigation.addItem(settings)

        bottom_navigation.accentColor = Color.parseColor("#F63D2B");
        bottom_navigation.inactiveColor = Color.parseColor("#747474");


    }

    fun setToolbarTittle(title: String) {

        toolbarText.setText(title)
    }


}